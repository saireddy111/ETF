﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessingLibrary.Models
{
    public enum OrderStatusEnum
    {
        ORDER_PLACED,
        OUT_OF_STOCK,
        PAYMENT_FAILURE,
        PROCESSING_ERROR,
        CARD_INVALID
    }
}
