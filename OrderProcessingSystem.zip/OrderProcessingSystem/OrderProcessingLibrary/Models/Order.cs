﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessingLibrary.Models
{
    public class Order
    {
        public string OrderId { get; set; }
        public string ProductId { get; set; }
        public int ProductQuantity { get; set; }
        public decimal ProductPrice { get; set; }
        public string CreditCardNumber { get; set; }
        public string ShippingAddress { get; set; }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("OrderId\t:\t" + OrderId + "\n");
            builder.Append("ProductId\t:\t" + ProductId + "\n");
            builder.Append("ProductQuantity\t:\t" + ProductQuantity + "\n");
            builder.Append("ProductPrice\t:\t" + ProductPrice + "\n");
            builder.Append("ShippingAddress\t:\t" + ShippingAddress + "\n");
            return builder.ToString();     
        }
    }
}
