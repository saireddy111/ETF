﻿using OrderProcessingLibrary.Models;

namespace OrderProcessingLibrary.Services
{
    public interface IOrderService
    {
        OrderStatusEnum ProcessOrder(Order order);
    }
}
