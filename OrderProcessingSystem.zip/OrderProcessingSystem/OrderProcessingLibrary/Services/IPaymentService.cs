﻿namespace OrderProcessingLibrary.Services
{
    public interface IPaymentService
    {
        bool IsCardValid(string creditCardNumber);
        bool ChargePayment(string creditCardNumber, decimal amount);
    }
}
