﻿using OrderProcessingLibrary.Models;
using OrderProcessingLibrary.Repositories;
using System;

namespace OrderProcessingLibrary.Services
{
    public class OrderService : IOrderService
    {
        IProductRepository productRepository;
        IEmailService emailService;
        IPaymentService paymentService;

        public OrderService(IProductRepository productRepository, IEmailService emailService, IPaymentService paymentService)
        {
            this.productRepository = productRepository;
            this.emailService = emailService;
            this.paymentService = paymentService;
        }

        public OrderStatusEnum ProcessOrder(Order order)
        {
            OrderStatusEnum orderStatus;
            try
            {
                bool isStockAvailable = productRepository.CheckInventory(order.ProductId, order.ProductQuantity);
                if (isStockAvailable)
                {
                    bool isCardValid = paymentService.IsCardValid(order.CreditCardNumber);
                    if (isCardValid)
                    {
                        decimal price = order.ProductPrice * order.ProductQuantity;
                        bool isPaymentCharged = paymentService.ChargePayment(order.CreditCardNumber, price);
                        if (isPaymentCharged)
                        {
                            string toEmail = "shipping@ProductCompany.com";
                            string subject = "New order placed, orderId: " + order.OrderId;
                            string body = "New order placed, please ship the following order\n" + order;
                            emailService.SendEmail(toEmail, subject, body);
                            orderStatus = OrderStatusEnum.ORDER_PLACED;
                        }
                        else
                        {
                            orderStatus = OrderStatusEnum.PAYMENT_FAILURE;
                        }
                    }
                    else
                    {
                        orderStatus = OrderStatusEnum.CARD_INVALID;
                    }        
                }
                else
                {
                    orderStatus = OrderStatusEnum.OUT_OF_STOCK;
                }
            }
            catch (Exception)
            {
                orderStatus = OrderStatusEnum.PROCESSING_ERROR;
            }
            return orderStatus;
        }
    }
}
