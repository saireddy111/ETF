﻿namespace OrderProcessingLibrary.Repositories
{
    public interface IProductRepository
    {
        bool CheckInventory(string productId, int qty);
    }
}
