﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessingLibrary.Services;
using Moq;
using OrderProcessingLibrary.Repositories;
using OrderProcessingLibrary.Models;

namespace OrderProcessingLibrary.Tests
{
    [TestClass]
    public class OrderServiceTest
    {
        IOrderService orderService;
        Order order;
        [TestInitialize]
        public void SetUp()
        {
            Mock<IProductRepository> mockProductRepository = new Mock<IProductRepository>();
            Mock<IEmailService> mockEmailService = new Mock<IEmailService>();
            Mock<IPaymentService> mockPaymentService = new Mock<IPaymentService>();

            mockProductRepository
                .Setup(m => m.CheckInventory(It.IsAny<string>(), It.IsAny<int>()))
                .Returns((string productId, int qty) =>{ return productId.Equals("AvialableProductId") ? (qty > 0 && qty < 10) : false; });

            mockEmailService.Setup(m => m.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));

            mockPaymentService
                .Setup(m => m.IsCardValid(It.IsAny<string>()))
                .Returns((string creditCardNumber) =>{ return creditCardNumber.Equals("ValidNumber"); });

            mockPaymentService
              .Setup(m => m.ChargePayment(It.IsAny<string>(), It.IsAny<decimal>()))
              .Returns((string creditCardNumber, decimal amount) => { return (amount > 0 && amount < 1000); });

            orderService = new OrderService(mockProductRepository.Object, mockEmailService.Object, mockPaymentService.Object);

            order = new Order()
            {
                OrderId = "OrderId",
                ProductId = "AvialableProductId",
                ProductPrice = 20.6M,
                ProductQuantity = 8,
                CreditCardNumber = "ValidNumber",
                ShippingAddress = "1000 Street, Good City, ST, 50106"
            };
        }

        [TestMethod]
        public void ProcessOrder_GivenNotAvailabelProductStock_ShouldReturn_Out_Of_Stock()
        {
            order.ProductQuantity = 30;
            var actualResult = orderService.ProcessOrder(order);
            var expectedResult = OrderStatusEnum.OUT_OF_STOCK;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void ProcessOrder_GivenNotAvailabelProductId_ShouldReturn_Out_Of_Stock()
        {
            order.ProductId = "NotAvailabelProductId";
            var actualResult = orderService.ProcessOrder(order);
            var expectedResult = OrderStatusEnum.OUT_OF_STOCK;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void ProcessOrder_GivenInValidCreditCardNumber_ShouldReturn_Card_InValid()
        {
            order.CreditCardNumber = "InValidNumber";
            var actualResult = orderService.ProcessOrder(order);
            var expectedResult = OrderStatusEnum.CARD_INVALID;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void ProcessOrder_GivenInSufficentAmount_ShouldReturn_Payment_Failure()
        {
            order.ProductPrice = 200M;
            order.ProductQuantity = 9;
            var actualResult = orderService.ProcessOrder(order);
            var expectedResult = OrderStatusEnum.PAYMENT_FAILURE;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void ProcessOrder_GivenValidOrder_ShouldReturn_Order_Placed()
        {
            order.ProductPrice = 10M;
            order.ProductQuantity = 9;
            var actualResult = orderService.ProcessOrder(order);
            var expectedResult = OrderStatusEnum.ORDER_PLACED;
            Assert.AreEqual(expectedResult, actualResult);
        }


    }
}
